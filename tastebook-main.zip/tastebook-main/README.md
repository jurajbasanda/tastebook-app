
## Recipe website - tastebook  ##
MongoDB<br/>
Express.js<br/>
React.js<br/>
Node.js<br/>


Open http://localhost:3000 to view it in the browser<br/>
Server running on port 5000

### Satart app
npm run dev

### Start backend side<br/>
npm run server

### Start frontend side<br/>
npm run client


